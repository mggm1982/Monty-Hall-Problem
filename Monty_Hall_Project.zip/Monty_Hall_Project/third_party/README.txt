INCLUDED THIRD-PARTY LIBRARY
============================

Library: Simple DirectMedia Layer (SDL2)
Version: 2.32.10
Author: SDL contributors; see the included archive's CREDITS.txt.
License: zlib; preserved in SDL2-LICENSE.txt and in the original archive.

The full, unmodified official source distribution is included as
SDL2-2.32.10.tar.gz. It contains headers, implementation, platform build
files, and upstream documentation. CMakeLists.txt extracts and builds it
locally. No separate SDL2 installation is required for that build method.

Official release:
https://github.com/libsdl-org/SDL/releases/tag/release-2.32.10
Downloaded archive:
https://github.com/libsdl-org/SDL/releases/download/release-2.32.10/SDL2-2.32.10.tar.gz
Alternate official download:
https://www.libsdl.org/release/SDL2-2.32.10.tar.gz

SHA-256 of included archive (integrity record):
5f5993c530f084535c65a6879e9b26ad441169b3e25d789d83287040a9ca5165

This is native SDL2, while the author's existing Mac/Homebrew setup uses
sdl2-compat 2.32.74 backed by SDL3. Both expose the SDL2 API used by the
project. Only the native SDL2 source is bundled; package-manager commands
in the main README install each platform's development package separately.

Compilers, operating-system SDKs, CMake, and package managers are not bundled.
Install the prerequisites in the main README before building.
