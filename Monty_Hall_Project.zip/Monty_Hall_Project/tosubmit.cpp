#include <SDL2/SDL.h>
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

const int W = 1000, H = 640;                
const int GX = 40, GY = 100, GSIZE = 460;   
const int PX = 540, PW = 420;               
const int BATCH = 250;                      
const int MAXPTS = 4000;                    

int N = 100;       
int TOTAL = 10000;  

SDL_Renderer* ren;  
const SDL_Color BG     = {16, 18, 25};
const SDL_Color WHITE  = {235, 235, 240};
const SDL_Color GREY   = {160, 165, 180};
const SDL_Color BLUE   = {65, 170, 245};
const SDL_Color ORANGE = {240, 155, 70};
const SDL_Color YELLOW = {245, 195, 65};
const SDL_Color GREEN  = {80, 230, 130};
const SDL_Color PANEL  = {35, 38, 48};


const char* CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789%./?-:";

const char* FONT[][7] = {
     {"01110","10001","10001","11111","10001","10001","10001"},
    {"11110","10001","10001","11110","10001","10001","11110"},
    {"01110","10001","10000","10000","10000","10001","01110"},
    {"11110","10001","10001","10001","10001","10001","11110"},
    {"11111","10000","10000","11110","10000","10000","11111"},
    {"11111","10000","10000","11110","10000","10000","10000"},
    {"01110","10001","10000","10111","10001","10001","01111"},
    {"10001","10001","10001","11111","10001","10001","10001"},
    {"11111","00100","00100","00100","00100","00100","11111"},
    {"00111","00010","00010","00010","00010","10010","01100"},
    {"10001","10010","10100","11000","10100","10010","10001"},
    {"10000","10000","10000","10000","10000","10000","11111"},
    {"10001","11011","10101","10101","10001","10001","10001"},
    {"10001","11001","10101","10011","10001","10001","10001"},
    {"01110","10001","10001","10001","10001","10001","01110"},
    {"11110","10001","10001","11110","10000","10000","10000"},
    {"01110","10001","10001","10001","10101","10010","01101"},
    {"11110","10001","10001","11110","10100","10010","10001"},
    {"01111","10000","10000","01110","00001","00001","11110"},
    {"11111","00100","00100","00100","00100","00100","00100"},
    {"10001","10001","10001","10001","10001","10001","01110"},
    {"10001","10001","10001","10001","10001","01010","00100"},
    {"10001","10001","10001","10101","10101","11011","10001"},
    {"10001","10001","01010","00100","01010","10001","10001"},
    {"10001","10001","01010","00100","00100","00100","00100"},
    {"11111","00001","00010","00100","01000","10000","11111"},
    {"01110","10001","10011","10101","11001","10001","01110"},
    {"00100","01100","00100","00100","00100","00100","01110"},
    {"01110","10001","00001","00010","00100","01000","11111"},
    {"11110","00001","00001","01110","00001","00001","11110"},
    {"00010","00110","01010","10010","11111","00010","00010"},
    {"11111","10000","10000","11110","00001","00001","11110"},
    {"01110","10000","10000","11110","10001","10001","01110"},
    {"11111","00001","00010","00100","01000","01000","01000"},
    {"01110","10001","10001","01110","10001","10001","01110"},
    {"01110","10001","10001","01111","00001","00001","01110"},
    {"11001","11010","00100","01000","10110","01011","00000"},
    {"00000","00000","00000","00000","00000","00110","00110"},
    {"00001","00010","00010","00100","01000","01000","10000"},
    {"01110","10001","00001","00010","00100","00000","00100"},
    {"00000","00000","00000","11111","00000","00000","00000"},
    {"00000","00110","00110","00000","00110","00110","00000"},
};

int findGlyph(char c) {
    for (int i = 0; CHARS[i] != '\0'; i++)
        if (CHARS[i] == c) return i;
    return -1;
}


void setColor(SDL_Color c) {
    SDL_SetRenderDrawColor(ren, c.r, c.g, c.b, 255);
}

void fill(int x, int y, int w, int h, SDL_Color c) {
    setColor(c);
    SDL_Rect q = {x, y, w, h};
    SDL_RenderFillRect(ren, &q);
}


void frame(int x, int y, int w, int h, int t, SDL_Color c) {
    fill(x, y, w, t, c);            
    fill(x, y + h - t, w, t, c);  
    fill(x, y, t, h, c);            
    fill(x + w - t, y, t, h, c);    
}
void text(string s, int x, int y, int z, SDL_Color c) {
    int n = s.length();
    for (int k = 0; k < n; k++) {
        int g = findGlyph(s[k]);
        if (g >= 0) {
            for (int row = 0; row < 7; row++)
                for (int col = 0; col < 5; col++)
                    if (FONT[g][row][col] == '1')
                        fill(x + col * z, y + row * z, z, z, c);
        }
        x += 6 * z;    
    }
}

int tw(string s, int z) {
    int n = s.length();
    if (n == 0) return 0;
    return n * 6 * z - z;
}

void center(string s, int cx, int y, int z, SDL_Color c) {
    text(s, cx - tw(s, z) / 2, y, z, c);
}

string percent(double p) {
    int v = (int)(p * 100 + 0.5);           
    string frac = to_string(v % 100);
    if (v % 100 < 10) frac = "0" + frac;    
    return to_string(v / 100) + "." + frac + "%";
}

int cols, pitch, cell, gx0, numZ;

void setupLayout() {
    if (N <= 5) cols = N;
    else {
        cols = 1;
        while (cols * cols < N) cols++;
    }
    int rows = (N + cols - 1) / cols;

    pitch = 150;
    if (GSIZE / cols < pitch) pitch = GSIZE / cols;
    if (GSIZE / rows < pitch) pitch = GSIZE / rows;
    if (pitch >= 60) cell = pitch - 10;
    else cell = pitch - 4;
    gx0 = GX + (GSIZE - cols * pitch) / 2;

    int digits = 1;
    if (N >= 10) digits = 2;
    if (N >= 100) digits = 3;
    numZ = (cell - 6) / (6 * digits);
    if (numZ > 4) numZ = 4;
    if (numZ < 1) numZ = 1;
}

void door(int i, bool opened, bool pick, bool sw, bool prize) {
    int x = gx0 + (i % cols) * pitch;
    int y = GY + (i / cols) * pitch;

    SDL_Color body = {55, 65, 90};
    if (opened) body = {30, 30, 38};
    if (prize)  body = {45, 125, 75};

    SDL_Color edge = {120, 130, 155};
    if (opened) edge = {48, 48, 58};
    if (sw)     edge = YELLOW;
    if (pick)   edge = BLUE;

    fill(x, y, cell, cell, body);

    int t = 1;                     
    if (cell >= 60) t = 2;
    if (pick || sw) t = t * 2;      
    frame(x, y, cell, cell, t, edge);

    string s = to_string(i + 1);
    SDL_Color nc = WHITE;
    if (opened) nc = {75, 75, 88};
    text(s, x + (cell - tw(s, numZ)) / 2,
         y + (cell - 7 * numZ) / 2, numZ, nc);
}

void bar(int y, string label, double pct, SDL_Color c) {
    text(label, PX, y + 4, 3, WHITE);

    int bx = PX + 120, bw = PW - 120, bh = 30;
    fill(bx, y, bw, bh, PANEL);                        
    fill(bx, y, (int)(bw * pct / 100.0), bh, c);       
    text(percent(pct), bx + 10, y + 5, 3, {245, 245, 245});
}

int toY(double v, int y, int h) {
    return y + h - 1 - (int)((h - 1) * v / 100.0);
}

void dotted(int y, int h, double v) {
    int ty = toY(v, y, h);
    for (int x = PX; x < PX + PW; x += 8)
        fill(x, ty, 4, 1, {95, 100, 115});
}

void plot(double v[], int count, int pts, int y, int h, SDL_Color c) {
    setColor(c);
    for (int i = 1; i < count; i++) {
        int x1 = PX + (i - 1) * (PW - 1) / (pts - 1);
        int x2 = PX + i * (PW - 1) / (pts - 1);
        SDL_RenderDrawLine(ren, x1, toY(v[i - 1], y, h),
                                x2, toY(v[i], y, h));
    }
}

void graph(int y, int h, double sw[], double st[], int count) {
    fill(PX, y, PW, h, PANEL);

    dotted(y, h, 100.0 * (N - 1) / N);      
    dotted(y, h, 100.0 / N);                

    int pts = (TOTAL + BATCH - 1) / BATCH;  
    plot(sw, count, pts, y, h, BLUE);
    plot(st, count, pts, y, h, ORANGE);

    frame(PX, y, PW, h, 1, {70, 75, 90});
}

void legend(int x, int y, string s, SDL_Color c) {
    fill(x, y, 14, 14, c);
    text(s, x + 22, y, 2, GREY);
}

int aPick, aOther, aPrize;      
int order[100];                 
int orderCount;
int clk;                        
const int PICK_END = 25, OPEN_END = 80, OFFER_END = 110, END = 155;

void newGame() {
    aPrize = rand() % N;
    aPick = rand() % N;
    if (aPick == aPrize) {
        aOther = rand() % N;
        while (aOther == aPick) aOther = rand() % N;
    } else {
        aOther = aPrize;
    }

    orderCount = 0;
    for (int i = 0; i < N; i++) {
        if (i != aPick && i != aOther) {
            order[orderCount] = i;
            orderCount++;
        }
    }

    for (int i = orderCount - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int tmp = order[i];
        order[i] = order[j];
        order[j] = tmp;
    }

    clk = 0;
}
int main(int argc, char* argv[]) {
    if (argc > 1) N = atoi(argv[1]);
    if (argc > 2) TOTAL = atoi(argv[2]);
    if (N < 3) N = 3;
    if (N > 100) N = 100;
    if (TOTAL < 1) TOTAL = 1;
    if (TOTAL > MAXPTS * BATCH) TOTAL = MAXPTS * BATCH;

    srand(time(0));
    setupLayout();

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        cout << "SDL error: " << SDL_GetError() << endl;
        return 1;
    }

    string title = "Monty Hall - " + to_string(N) + " Doors, " +
                   to_string(TOTAL) + " Trials";
    SDL_Window* win = SDL_CreateWindow(
        title.c_str(), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        W, H, SDL_WINDOW_SHOWN);
    ren = SDL_CreateRenderer(win, -1, 0);

    if (win == NULL || ren == NULL) {
        cout << "SDL window/renderer error: " << SDL_GetError() << endl;
        SDL_Quit();
        return 1;
    }

    int trials = 0, stayWins = 0, switchWins = 0;
    double histSw[MAXPTS], histSt[MAXPTS];   
    int histCount = 0;

    bool opened[100];
    bool running = true;
    bool fast = false;
    newGame();

    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) running = false;
            if (e.type == SDL_KEYDOWN) {
                if (e.key.keysym.sym == SDLK_ESCAPE) running = false;
                if (e.key.keysym.sym == SDLK_SPACE) fast = true;
            }
            if (e.type == SDL_KEYUP && e.key.keysym.sym == SDLK_SPACE)
                fast = false;
        }

        if (trials < TOTAL) {
            if (fast) clk = clk + 12;
            else clk = clk + 1;

            if (clk >= END) {
                for (int i = 0; i < BATCH && trials < TOTAL; i++) {
                    int prize = rand() % N;
                    int pick = rand() % N;
                    if (pick == prize) stayWins++;
                    else switchWins++;
                    trials++;
                }
                histSw[histCount] = 100.0 * switchWins / trials;
                histSt[histCount] = 100.0 * stayWins / trials;
                histCount++;

                if (trials < TOTAL) newGame();
                else clk = END - 1;     
            }
        }

        int stage;
        if (clk < PICK_END) stage = 0;
        else if (clk < OPEN_END) stage = 1;
        else if (clk < OFFER_END) stage = 2;
        else stage = 3;

        int openN = 0;
        if (stage == 1)
            openN = orderCount * (clk - PICK_END) / (OPEN_END - PICK_END);
        if (stage >= 2) openN = orderCount;

        for (int i = 0; i < N; i++) opened[i] = false;
        for (int i = 0; i < openN; i++) opened[order[i]] = true;

        bool switchWin = (aOther == aPrize);

        fill(0, 0, W, H, BG);
        center("MONTY HALL", W / 2, 18, 5, WHITE);
        center(to_string(N) + " DOOR VERSION", W / 2, 62, 3, GREY);

        for (int i = 0; i < N; i++)
            door(i, opened[i], i == aPick,
                 stage >= 2 && i == aOther,
                 stage >= 3 && i == aPrize);

        int cx = PX + PW / 2;
        string phase;
        SDL_Color pc = WHITE;
        if (stage == 0)
            phase = "PLAYER PICKS DOOR " + to_string(aPick + 1);
        else if (stage == 1)
            phase = "HOST OPENS " + to_string(openN) + " GOATS";
        else if (stage == 2)
            phase = "SWITCH TO DOOR " + to_string(aOther + 1) + "?";
        else {
            if (switchWin) { phase = "SWITCH WINS"; pc = BLUE; }
            else           { phase = "STAY WINS";   pc = ORANGE; }
        }
        center(phase, cx, 105, 3, pc);

        legend(PX,       150, "PICK",   BLUE);
        legend(PX + 92,  150, "SWITCH", YELLOW);
        legend(PX + 208, 150, "PRIZE",  GREEN);

        double sw = 0, st = 0;
        if (trials > 0) {
            sw = 100.0 * switchWins / trials;
            st = 100.0 * stayWins / trials;
        }
        bar(200, "SWITCH", sw, BLUE);
        bar(250, "STAY", st, ORANGE);

        text("CONVERGENCE", PX, 294, 2, GREY);
        graph(314, 116, histSw, histSt, histCount);

        center("TRIALS", cx, 448, 3, {190, 195, 205});
        center(to_string(trials) + " / " + to_string(TOTAL),
               cx, 478, 4, WHITE);

        fill(PX + 20, 520, PW - 40, 16, PANEL);
        fill(PX + 20, 520, (int)((PW - 40) * (double)trials / TOTAL), 16,
             {90, 205, 130});

        center("THEORY SWITCH " + percent(100.0 * (N - 1) / N) +
               " STAY " + percent(100.0 / N), cx, 558, 2, GREY);

        string hint = "HOLD SPACE TO SPEED UP";
        if (fast) hint = "FAST FORWARD";
        if (trials >= TOTAL) hint = "DONE - CLOSE WINDOW FOR RESULT";
        center(hint, cx, 590, 2, {110, 115, 130});

        SDL_RenderPresent(ren);
        SDL_Delay(16);    
    }
    int n = trials;
    if (n < 1) n = 1;
    cout << "   MONTY HALL RESULT (" << N << " doors)\n";
    cout << "Trials:      " << trials << "\n";
    cout << "Switch wins: " << switchWins << " / " << trials << " = "
         << 100.0 * switchWins / n << "%\n";
    cout << "Stay wins:   " << stayWins << " / " << trials << " = "
         << 100.0 * stayWins / n << "%\n";
    cout << "Theory:      Switch " << 100.0 * (N - 1) / N
         << "%, Stay " << 100.0 / N << "%\n";

    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}